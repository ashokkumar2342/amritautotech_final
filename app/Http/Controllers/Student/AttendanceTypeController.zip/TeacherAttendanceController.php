<?php

namespace App\Http\Controllers\Admin;

use App\TeacherAttendance;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class TeacherAttendanceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\TeacherAttendance  $teacherAttendance
     * @return \Illuminate\Http\Response
     */
    public function show(TeacherAttendance $teacherAttendance)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\TeacherAttendance  $teacherAttendance
     * @return \Illuminate\Http\Response
     */
    public function edit(TeacherAttendance $teacherAttendance)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\TeacherAttendance  $teacherAttendance
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, TeacherAttendance $teacherAttendance)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\TeacherAttendance  $teacherAttendance
     * @return \Illuminate\Http\Response
     */
    public function destroy(TeacherAttendance $teacherAttendance)
    {
        //
    }
}
