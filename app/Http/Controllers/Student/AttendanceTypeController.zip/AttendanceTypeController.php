<?php

namespace App\Http\Controllers\Admin;

use App\AttendanceType;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AttendanceTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\AttendanceType  $attendanceType
     * @return \Illuminate\Http\Response
     */
    public function show(AttendanceType $attendanceType)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\AttendanceType  $attendanceType
     * @return \Illuminate\Http\Response
     */
    public function edit(AttendanceType $attendanceType)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\AttendanceType  $attendanceType
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AttendanceType $attendanceType)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\AttendanceType  $attendanceType
     * @return \Illuminate\Http\Response
     */
    public function destroy(AttendanceType $attendanceType)
    {
        //
    }
}
