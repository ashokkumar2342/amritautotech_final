 @extends('front.layout.main')
@push('styles')
 
@endpush
@section('body')

    
  <!--Page Title-->
        <section class="page-title">
            <div class="container">
                <div class="row clearfix">
                    <div class="col-md-6 col-sm-6 col-xs-12 pull-left">
                        <h1>Assignments</h1>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12 pull-right text-right path"><a href="{{ route('front.home') }}">Home</a>&ensp;>&ensp;<a href="#">Assignments</a>
                    </div>
                    <div class="overlay"></div>
                </div>
            </div>
        </section>
        <!--Page Title Ends-->
		<!--about style-two start-->
        <section class="about style-two">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2">
						<div class="col-md-8">
							<img src="{{ asset('assets/images/Homework/h1.png') }}" style="width:200px;height:100px;"></img>
						</div>
						<div class="col-md-4 col-xs-12 hidden-xs">
							<img src="{{ asset('assets/images/Homework/h2.png') }}" style="width:200px;height:100px"></img>
						</div>
					</div>
				</div>
					<br><br>
				<div class="col-md-8 col-md-offset-2">
					<table class="table table-bordered">
						<thead>
							<tr>
								<th>Sr. No.</th>
								<th>Date</th>
								<th>Title</th>
								<th>Download</th>
								</tr>
						</thead>
						<tbody>
						 
						 
						   @foreach($holidayhomeworks as $holidayhomework)
				                <tr>
				                  <td>{{ $loop->index+1 }}</td>
				                  <td>{{ $holidayhomework->created_at }}</td>                  
				                   
				                  <td>{{ $holidayhomework->title }}</td>
				                  <td align="center">
				                    <a class="btn btn-success btn-xs" href="/storage/file/{{$holidayhomework->holiday_homework }}"><i class="fa fa-download"></i></a>
				                  </td>                 
				                </tr>
				            @endforeach
								  
						</tbody>
					</table>
				</div>
			</div>
        </section>
        <!--about style-two end-->
 
    
@endsection
@push('scripts')


<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
@if(Session::has('message'))
<script type="text/javascript">
    Command: toastr["{{ Session::get('class') }}"]("{{ Session::get('message') }}");
</script>
@endif
@endpush

