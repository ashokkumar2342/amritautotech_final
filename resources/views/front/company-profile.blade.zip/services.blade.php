@extends('front.layout.main')
@push('styles')
 
@endpush
@section('body')    
  <!--Page Title-->
      <section class="page-title">
        <div class="container">
          <div class="row clearfix">
            <div class="col-md-6 col-sm-6 col-xs-12 pull-left">
              <h1> </h1>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-12 pull-right text-right path"> 
            </div>
            <div class="overlay"></div>
          </div>
        </div>
      </section>
      <!--Page Title Ends-->
      <!--about style-two start-->
      <section class="about style-two">
        <div class="container">
          <div style="text-align:justify;">            
             
            <h3> Services</h3>
            <div class="row">
              <div class="col-md-8">
                <p style="text-align:justify">                 
                  Here we want to express our heartfelt gratitude to our clients for the trust they have been
                  Placing in Auto mobile Sector, since 2015, over fifteen major companies have been our clients. We have proven our expertise and experience in a number of industries and provided PR consulting on a number of topics. 
                  Service agreements is proof of the positive effect of our activities on our clients’ business.
                  </p>
                  <p align="justify"><b>We have tool room facility for Machine Manufacturing
                  Machines details:-
                  </b></p>
                  <ol>
                    <li><p>lathe machineno. 02</p></li>
                    <li><p>Milling machine   no. 01</p></li>
                    <li><p>Surface Grinder   no. 02</p></li>
                    <li><p>Fix Drill Machine      no. 02</p></li>
                    <li><p>Hand Drill Machine  no.01</p></li>

                  </ol>
                  <p align="justify">
                    Production companies usually propose to client’s ways of delivering what is demanded fromthem. AAE, however, provides services at an earlier stage of planning and helps clients searchfor the most effective ways to communicate key messages. Such an approach brings effectiveresults at lower costs.
                  </p>
             <h2>InhouseMachineDesigning& Manufacturing </h2>
             <hr>
             <div class="row">
               <div class="col-md-6">
                 <img src="{{ asset('assets/images/background/1.jpg') }}" class="thumbnail"  alt="service ">
               </div>
               <div class="col-md-6">
                 <img src="{{ asset('assets/images/background/2.jpg') }}" class="thumbnail"  alt="service ">
               </div>
               <div class="col-md-6">
                 <img src="{{ asset('assets/images/background/3.jpg') }}" class="thumbnail"  alt="service ">
               </div>
               <div class="col-md-6">
                 <img src="{{ asset('assets/images/background/4.jpg') }}" class="thumbnail"  alt="service ">
               </div>
             </div>

              </div>
                <!--Sidebar-->
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <aside class="sidebar">


                            <!-- Popular Categories -->
                            <div class="widget popular-categories wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <div class="sidebar-title">
                                    <h3>Quick Links</h3>
                                </div>

                                <ul class="list ">
                                    <li><a href="{{ route('front.about') }}"><span class="icon-left fa fa-chevron-right"></span>About Company</a>
                                    </li>
                                {{--     <li><a href="{{ route('front.company-profile') }}"><span class="icon-left fa fa-chevron-right"></span>Company Profile</a> --}}
                                    </li>
                                    <li><a href="{{ route('front.managing-director') }}"><span class="icon-left fa fa-chevron-right"></span>Managing Director</a>
                                    </li>
                                    
                                    <li><a href="{{ route('front.executive-director') }}"><span class="icon-left fa fa-chevron-right"></span>Executive Director </a>
                                    </li>
                                    
                                    
                                </ul>

                            </div>
                            <!-- End of .sidebar_tags -->


                        </aside>
                    </div>
                    <!--Sidebar-->
            </div>
            
           </div> 
        </div>
      </section>
@endsection
@push('scripts')


<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
@if(Session::has('message'))
<script type="text/javascript">
    Command: toastr["{{ Session::get('class') }}"]("{{ Session::get('message') }}");
</script>
@endif
@endpush

